# Yoyo-abp-modules

本仓库由52ABP团队进行维护，以下的模块都是由52ABP组织发布的Nuget包，开箱即用。

 


[![Build Status](http://ltm.eastasia.cloudapp.azure.com/job/Yoyosoft-abp-modules/job/master/badge/icon)](http://ltm.eastasia.cloudapp.azure.com/blue/organizations/jenkins/Yoyosoft-abp-modules/activity/)



## Nuget包



| Package | Status |Doc|
| :--- | :--- | :--- |
|Yoyo.Abp.Alipay|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Alipay.svg)](https://badge.fury.io/nu/Yoyo.Abp.Alipay)|[文档](src/Yoyo.Abp.Alipay/README.md)|
|Yoyo.Abp.Aliyun.Vod|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Aliyun.Vod.svg)](https://badge.fury.io/nu/Yoyo.Abp.Aliyun.Vod)|todo|
|Yoyo.Abp.Wechat|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat)|todo|
|Yoyo.Abp.Wechat.MP|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.MP.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat.MP)|todo|
|Yoyo.Abp.Wechat.Open|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.Open.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat.Open)|todo|
|Yoyo.Abp.Wechat.TenPay|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.TenPay.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat.TenPay)|todo|
|Yoyo.Abp.Wechat.Work|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.Work.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat.Work)|todo|
|Yoyo.Abp.Wechat.WxOpen|[![NuGet version](https://badge.fury.io/nu/Yoyo.Abp.Wechat.WxOpen.svg)](https://badge.fury.io/nu/Yoyo.Abp.Wechat.WxOpen)|todo|

|todo|todo|todo|
 