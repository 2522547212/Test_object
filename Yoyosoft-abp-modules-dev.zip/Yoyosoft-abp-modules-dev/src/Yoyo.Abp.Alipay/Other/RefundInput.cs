using Alipay.AopSdk.Core.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Yoyo.Abp.Other
{
    public class RefundInput
    {
        public AlipayTradeRefundModel Data { get; set; }
    }
}
