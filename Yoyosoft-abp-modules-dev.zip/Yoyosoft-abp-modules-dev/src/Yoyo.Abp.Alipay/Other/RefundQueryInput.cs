using Alipay.AopSdk.Core.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Yoyo.Abp.Other
{
    public class RefundQueryInput
    {
        public AlipayTradeFastpayRefundQueryModel Data { get; set; }
    }
}
