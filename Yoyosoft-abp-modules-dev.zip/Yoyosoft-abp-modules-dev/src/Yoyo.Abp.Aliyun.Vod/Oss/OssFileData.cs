﻿namespace Yoyo.Abp.Oss
{
    public class OssFileData
    {
        public string Url { get; set; }
    }
}
