﻿namespace Yoyo.Abp.Vod.model
{
    /// <summary>
    /// 二次封装的方法
    /// </summary>
    public class SearchMediaInputDto
    {
        
    }
}