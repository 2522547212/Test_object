using Abp;
using Abp.Modules;
using System;
using System.Collections.Generic;
using System.Text;

namespace Yoyo.Abp
{
    /// <summary>
    /// YoYo Soft Senparc.WeiXin.Work  Module
    /// </summary>
    [DependsOn(typeof(AbpKernelModule))]
    public class YoyoAbpWechatWorkModule : AbpModule
    {

    }
}
