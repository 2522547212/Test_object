using Abp;
using Abp.Modules;
using System;
using System.Collections.Generic;
using System.Text;

namespace Yoyo.Abp
{
    /// <summary>
    /// YoYo Soft Senparc.WeiXin.WxOpen  Module
    /// </summary>
    [DependsOn(typeof(AbpKernelModule))]
    public class YoyoAbpWechatWxOpenModule : AbpModule
    {

    }
}
