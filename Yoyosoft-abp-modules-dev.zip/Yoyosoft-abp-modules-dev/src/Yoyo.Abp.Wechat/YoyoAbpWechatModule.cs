using Abp;
using Abp.Modules;
using System;

namespace Yoyo.Abp
{
    /// <summary>
    /// YoYo Soft Senparc.WeiXin  Module
    /// </summary>
    [DependsOn(typeof(AbpKernelModule))]
    public class YoyoAbpWechatModule : AbpModule
    {

    }
}
